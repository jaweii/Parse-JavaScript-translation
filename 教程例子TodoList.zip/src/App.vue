<template>
    <div id="app">
        <mu-appbar>
            <mu-text-field type="text" hintText="Todo List" v-model="value">
            </mu-text-field>
            <mu-icon-button icon="add" slot="right" @click="addItem">
            </mu-icon-button>
        </mu-appbar>
        <mu-list>
            <mu-list-item v-for="item in list" :title="item.get('title')" :describeText="item.get('finish')?'完成':'未完成'">
                <mu-icon-button icon="check" slot="left" @click="finishItem(item)" :disabled="item.get('finish')">
                </mu-icon-button>
                <mu-icon-button icon="delete" slot="right" @click="deleteItem(item)">
                </mu-icon-button>
            </mu-list-item>
        </mu-list>
        <div style="text-align:center;" v-if="!list.length">暂无任务</div>
        </section>
    </div>
</template>
<script>
import parse from 'parse'
parse.serverURL = 'http://localhost:2018/parse'
parse.initialize('myAppId', '123456')
export default {
    name: 'App',
    data() {
        return {
            value: '',
            list: []
        }
    },
    mounted() {
        let query = new parse.Query('Todo')
        query.find().then(list => {
            this.list = list
        })
    },
    methods: {
        addItem() {
            if (!this.value)
                return
            let todo = new parse.Object('Todo')
            todo.set('title', this.value)
            todo.set('finish', false)
            todo.save().then(todo => {
                this.list.push(todo)
                this.value = ''
            }).catch(console.error)
        },
        finishItem(todo) {
            todo.set('finish', true).save().then(todo => {
                this.$forceUpdate()
            }).catch(console.error)
        },
        deleteItem(todo) {
            todo.destroy().then(todo => {
                this.list = this.list.filter(item => item !== todo)
            }).catch(console.error)
        }
    }
}
</script>
<style>
@import "http://cdn.bootcss.com/material-design-icons/3.0.1/iconfont/material-icons.css";
#app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    max-width: 400px;
    left: 0;
    right: 0;
    margin: auto;
}
</style>
